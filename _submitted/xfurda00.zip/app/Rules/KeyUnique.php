<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class KeyUnique implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $keys = array_keys($value);
        
        return count($keys) == count(array_unique($keys));
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'Odeslaný klíč nebyl unikátní.';
    }
}
